<?php

declare(strict_types=1);

// ---------------------------------------------------------------------------
// Router for PHP built-in development server
// ---------------------------------------------------------------------------

// When running under the built-in server, serve static files directly.
// Only API routes (starting with /api/) go through the dispatcher.
$requestUri = $_SERVER['REQUEST_URI'] ?? '/';
$uriPath = parse_url($requestUri, PHP_URL_PATH) ?: '/';

if (PHP_SAPI === 'cli-server' && $uriPath !== '/api' && !str_starts_with($uriPath, '/api/')) {
    $docRoot = __DIR__ . '/..';

    if ($uriPath === '/' || $uriPath === '') {
        readfile($docRoot . '/models.html');
        exit;
    }

    $staticFile = $docRoot . $uriPath;
    if (is_file($staticFile)) {
        return false;
    }
}

// ---------------------------------------------------------------------------
// API dispatcher — only reaches here for /api/* routes
// ---------------------------------------------------------------------------

// Set JSON content type for all API responses (Requirement 7.1)
header('Content-Type: application/json');

// ---------------------------------------------------------------------------
// Helper functions (globally available to handlers)
// ---------------------------------------------------------------------------

/**
 * Send a JSON response with the given data and HTTP status code.
 *
 * @param mixed $data  The data to encode as JSON.
 * @param int   $code  HTTP status code (default 200).
 */
function jsonResponse(mixed $data, int $code = 200): never
{
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * Send a JSON error response with the given message and HTTP status code.
 *
 * @param string $message  Human-readable error description.
 * @param int    $code     HTTP status code (default 400).
 */
function jsonError(string $message, int $code = 400): never
{
    http_response_code($code);
    echo json_encode(['error' => $message], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// ---------------------------------------------------------------------------
// Bootstrap: initialise the database on every request (Requirement 8.5)
// ---------------------------------------------------------------------------

$db = require __DIR__ . '/../db/init.php';

// ---------------------------------------------------------------------------
// Routing — strip /api prefix and dispatch
// ---------------------------------------------------------------------------

// Strip the /api prefix from the URI path
$apiPath = $uriPath;
if (str_starts_with($apiPath, '/api')) {
    $apiPath = substr($apiPath, 4) ?: '/';
}
$apiPath = rtrim($apiPath, '/') ?: '/';

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

// Parse path segments: /resource[/:id]
// Expected patterns:
//   /models          → resource=models, id=null
//   /models/42       → resource=models, id=42
//   /auto-link       → resource=auto-link, id=null
$segments = explode('/', ltrim($apiPath, '/'));
$resource = $segments[0] ?? '';
$id       = isset($segments[1]) && $segments[1] !== '' ? $segments[1] : null;

// ---------------------------------------------------------------------------
// Dispatch
// ---------------------------------------------------------------------------

try {
    switch ($resource) {
        case 'models':
            require_once __DIR__ . '/handlers/ModelHandler.php';
            $handler = new ModelHandler($db);
            if ($id === null) {
                match ($method) {
                    'GET'  => $handler->index(),
                    'POST' => $handler->create(),
                    default => jsonError('Method Not Allowed', 405),
                };
            } else {
                match ($method) {
                    'GET'    => $handler->show((int) $id),
                    'PUT'    => $handler->update((int) $id),
                    'DELETE' => $handler->destroy((int) $id),
                    default  => jsonError('Method Not Allowed', 405),
                };
            }
            break;

        case 'nodes':
            require_once __DIR__ . '/handlers/NodeHandler.php';
            $handler = new NodeHandler($db);
            if ($id === null) {
                match ($method) {
                    'GET'  => $handler->index(),
                    'POST' => $handler->create(),
                    default => jsonError('Method Not Allowed', 405),
                };
            } else {
                match ($method) {
                    'GET'    => $handler->show((int) $id),
                    'PUT'    => $handler->update((int) $id),
                    'DELETE' => $handler->destroy((int) $id),
                    default  => jsonError('Method Not Allowed', 405),
                };
            }
            break;

        case 'connections':
            require_once __DIR__ . '/handlers/ConnectionHandler.php';
            $handler = new ConnectionHandler($db);
            if ($id === null) {
                match ($method) {
                    'GET'  => $handler->index(),
                    'POST' => $handler->create(),
                    default => jsonError('Method Not Allowed', 405),
                };
            } else {
                match ($method) {
                    'GET'    => $handler->show((int) $id),
                    'PUT'    => $handler->update((int) $id),
                    'DELETE' => $handler->destroy((int) $id),
                    default  => jsonError('Method Not Allowed', 405),
                };
            }
            break;

        case 'auto-link':
            require_once __DIR__ . '/handlers/AutoLinkHandler.php';
            $handler = new AutoLinkHandler($db);
            match ($method) {
                'POST'  => $handler->run(),
                default => jsonError('Method Not Allowed', 405),
            };
            break;

        default:
            jsonError('Not Found', 404);
    }
} catch (Throwable $e) {
    // Requirement 7.4 / 8.5: return HTTP 500 on unexpected exceptions
    error_log((string) $e);
    jsonError('Internal server error', 500);
}
