<?php

declare(strict_types=1);

/**
 * AutoLinkEngine — core logic for automatic connection creation.
 *
 * Algorithm (Requirements 5.2–5.6):
 *   1. Load all nodes from DB.
 *   2. For each pc/printer: find switch_access with matching cabinet segment.
 *      If none found, create SW-<cabinet> node of type switch_access.
 *      Create connection pc/printer ↔ switch_access if it doesn't exist.
 *   3. For each switch_access: find any switch_dist, create connection if missing.
 *   4. For each switch_dist: find any router, create connection if missing.
 *
 * Name parsing: split by "-", use index 2 (0-based) as cabinet segment.
 * Default schema: building-floor-cabinet-device → explode('-', $name)[2] ?? null
 *
 * Requirements: 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8
 */
class AutoLinkEngine
{
    /** @var array<string, mixed>[] All nodes loaded from DB, keyed by id after load */
    private array $nodes = [];

    /** Number of nodes created during this run. */
    private int $nodesCreated = 0;

    /** Number of connections created during this run. */
    private int $connectionsCreated = 0;

    /** @var string[] Errors collected during this run. */
    private array $errors = [];

    /** @var string[] Parse schema segment labels (e.g. ['building','floor','cabinet','device']) */
    private array $schema;

    /** Default schema when none is provided */
    private const DEFAULT_SCHEMA = ['building', 'floor', 'cabinet', 'device'];

    public function __construct(private readonly PDO $db, ?array $schema = null)
    {
        $this->schema = $schema ?? self::DEFAULT_SCHEMA;
    }

    // -------------------------------------------------------------------------
    // Public API
    // -------------------------------------------------------------------------

    /**
     * Run the Auto-Link algorithm.
     *
     * @return array{nodes_created: int, connections_created: int, errors: string[]}
     */
    public function run(): array
    {
        $this->nodesCreated     = 0;
        $this->connectionsCreated = 0;
        $this->errors           = [];

        // Step 1: load all nodes
        $this->loadNodes();

        // Step 2: pc/printer → switch_access
        $this->linkEndpointsToSwitchAccess();

        // Step 3: switch_access → switch_dist
        $this->linkSwitchAccessToSwitchDist();

        // Step 4: switch_dist → router
        $this->linkSwitchDistToRouter();

        return [
            'nodes_created'       => $this->nodesCreated,
            'connections_created' => $this->connectionsCreated,
            'errors'              => $this->errors,
        ];
    }

    // -------------------------------------------------------------------------
    // Private helpers — data loading
    // -------------------------------------------------------------------------

    /**
     * Load all node records from the database into $this->nodes.
     */
    private function loadNodes(): void
    {
        $stmt = $this->db->query('SELECT * FROM node ORDER BY id');
        $rows = $stmt->fetchAll();

        $this->nodes = [];
        foreach ($rows as $row) {
            $this->nodes[(int) $row['id']] = $row;
        }
    }

    // -------------------------------------------------------------------------
    // Private helpers — name parsing
    // -------------------------------------------------------------------------

    /**
     * Extract the cabinet segment from a node name using the configured schema.
     *
     * @return string|null  Cabinet segment value, or null if schema has no 'cabinet' label or name has fewer segments.
     */
    private function getCabinetSegment(string $name): ?string
    {
        $parts = explode('-', $name);
        $cabinetIndex = array_search('cabinet', $this->schema, true);
        if ($cabinetIndex === false) {
            return null;
        }
        return $parts[$cabinetIndex] ?? null;
    }

    // -------------------------------------------------------------------------
    // Private helpers — node lookup
    // -------------------------------------------------------------------------

    /**
     * Find all nodes of a given type from the current in-memory list.
     *
     * @return array<int, array<string, mixed>>  Map of id → node row.
     */
    private function getNodesByType(string $type): array
    {
        $result = [];
        foreach ($this->nodes as $id => $node) {
            if ($node['type'] === $type) {
                $result[$id] = $node;
            }
        }
        return $result;
    }

    /**
     * Find the first node of a given type from the current in-memory list.
     *
     * @return array<string, mixed>|null
     */
    private function getFirstNodeByType(string $type): ?array
    {
        foreach ($this->nodes as $node) {
            if ($node['type'] === $type) {
                return $node;
            }
        }
        return null;
    }

    /**
     * Find a switch_access node whose cabinet segment matches the given cabinet.
     * Also checks for auto-created nodes with the legacy "SW-<cabinet>" name pattern.
     *
     * @return array<string, mixed>|null
     */
    private function findSwitchAccessByCabinet(string $cabinet): ?array
    {
        foreach ($this->nodes as $node) {
            if ($node['type'] !== 'switch_access') {
                continue;
            }
            $nodeCabinet = $this->getCabinetSegment((string) $node['name']);
            if ($nodeCabinet === $cabinet) {
                return $node;
            }
            if ($node['name'] === 'SW-' . $cabinet) {
                return $node;
            }
        }
        return null;
    }

    // -------------------------------------------------------------------------
    // Private helpers — node creation
    // -------------------------------------------------------------------------

    /**
     * Create a new switch_access node named SW-<cabinet> and add it to the
     * in-memory list so subsequent steps can use it.
     *
     * @return array<string, mixed>  The newly created node row.
     * @throws RuntimeException  If the INSERT fails.
     */
    private function createSwitchAccessNode(string $cabinet): array
    {
        $name = 'SW-' . $cabinet;

        $stmt = $this->db->prepare(
            'INSERT INTO node (name, type) VALUES (:name, :type)'
        );
        $stmt->execute([
            ':name' => $name,
            ':type' => 'switch_access',
        ]);

        $id = (int) $this->db->lastInsertId();

        $newNode = [
            'id'       => $id,
            'name'     => $name,
            'type'     => 'switch_access',
            'model_id' => null,
            'ip'       => null,
            'mac'      => null,
        ];

        // Add to in-memory list so later steps can find it
        $this->nodes[$id] = $newNode;
        $this->nodesCreated++;

        return $newNode;
    }

    // -------------------------------------------------------------------------
    // Private helpers — connection management
    // -------------------------------------------------------------------------

    /**
     * Check whether a connection between two nodes already exists (in either direction).
     * Requirement 5.4 (idempotence).
     */
    private function connectionExists(int $nodeIdA, int $nodeIdB): bool
    {
        $stmt = $this->db->prepare(
            'SELECT id FROM connection
             WHERE (src_node_id = :a AND dst_node_id = :b)
                OR (src_node_id = :b2 AND dst_node_id = :a2)
             LIMIT 1'
        );
        $stmt->execute([
            ':a'  => $nodeIdA,
            ':b'  => $nodeIdB,
            ':b2' => $nodeIdB,
            ':a2' => $nodeIdA,
        ]);
        return $stmt->fetch() !== false;
    }

    /**
     * Create a connection between two nodes if one does not already exist.
     *
     * @return bool  True if a new connection was created, false if it already existed.
     * @throws RuntimeException  If the INSERT fails.
     */
    private function ensureConnection(int $srcId, int $dstId): bool
    {
        if ($this->connectionExists($srcId, $dstId)) {
            return false;
        }

        $stmt = $this->db->prepare(
            'INSERT INTO connection (src_node_id, dst_node_id) VALUES (:src, :dst)'
        );
        $stmt->execute([
            ':src' => $srcId,
            ':dst' => $dstId,
        ]);

        $this->connectionsCreated++;
        return true;
    }

    // -------------------------------------------------------------------------
    // Private helpers — algorithm steps
    // -------------------------------------------------------------------------

    /**
     * Step 2: For each pc/printer, find or create a matching switch_access,
     * then ensure a connection exists between them.
     * Requirements: 5.2, 5.3, 5.4
     */
    private function linkEndpointsToSwitchAccess(): void
    {
        foreach ($this->getNodesByType('pc') + $this->getNodesByType('printer') as $node) {
            $nodeName = (string) $node['name'];
            $nodeId   = (int) $node['id'];

            try {
                $cabinet = $this->getCabinetSegment($nodeName);

                if ($cabinet === null) {
                    $msg = "Node '{$nodeName}' (id={$nodeId}): cannot extract cabinet segment from name";
                    error_log('[AutoLinkEngine] ' . $msg);
                    $this->errors[] = $msg;
                    continue;
                }

                // Find or create switch_access
                $switchAccess = $this->findSwitchAccessByCabinet($cabinet);
                if ($switchAccess === null) {
                    $switchAccess = $this->createSwitchAccessNode($cabinet);
                }

                $switchId = (int) $switchAccess['id'];

                // Create connection if missing
                $this->ensureConnection($nodeId, $switchId);

            } catch (Throwable $e) {
                $msg = "Node '{$nodeName}' (id={$nodeId}) ↔ switch_access: " . $e->getMessage();
                error_log('[AutoLinkEngine] ' . $msg);
                $this->errors[] = $msg;
            }
        }
    }

    /**
     * Step 3: For each switch_access, find any switch_dist and ensure a connection.
     * Requirement: 5.5
     */
    private function linkSwitchAccessToSwitchDist(): void
    {
        $switchDist = $this->getFirstNodeByType('switch_dist');

        if ($switchDist === null) {
            // No switch_dist in the network — nothing to do
            return;
        }

        $switchDistId = (int) $switchDist['id'];

        foreach ($this->getNodesByType('switch_access') as $swAccess) {
            $swAccessId   = (int) $swAccess['id'];
            $swAccessName = (string) $swAccess['name'];

            try {
                $this->ensureConnection($swAccessId, $switchDistId);
            } catch (Throwable $e) {
                $msg = "switch_access '{$swAccessName}' (id={$swAccessId}) ↔ switch_dist id={$switchDistId}: " . $e->getMessage();
                error_log('[AutoLinkEngine] ' . $msg);
                $this->errors[] = $msg;
            }
        }
    }

    /**
     * Step 4: For each switch_dist, find any router and ensure a connection.
     * Requirement: 5.6
     */
    private function linkSwitchDistToRouter(): void
    {
        $router = $this->getFirstNodeByType('router');

        if ($router === null) {
            // No router in the network — nothing to do
            return;
        }

        $routerId = (int) $router['id'];

        foreach ($this->getNodesByType('switch_dist') as $swDist) {
            $swDistId   = (int) $swDist['id'];
            $swDistName = (string) $swDist['name'];

            try {
                $this->ensureConnection($swDistId, $routerId);
            } catch (Throwable $e) {
                $msg = "switch_dist '{$swDistName}' (id={$swDistId}) ↔ router id={$routerId}: " . $e->getMessage();
                error_log('[AutoLinkEngine] ' . $msg);
                $this->errors[] = $msg;
            }
        }
    }
}

// =============================================================================

/**
 * AutoLinkHandler — HTTP handler for POST /api/auto-link.
 *
 * Wraps AutoLinkEngine and returns a JSON summary.
 *
 * Response codes:
 *   200 — success (or partial success with no errors, or connections_created > 0)
 *   207 — no connections created AND there are errors (Multi-Status)
 *
 * Requirements: 5.1, 5.7, 5.8
 */
class AutoLinkHandler
{
    public function __construct(private readonly PDO $db) {}

    /**
     * Run the Auto-Link engine and return a JSON summary.
     * Accepts optional "schema" array in the request body.
     * HTTP 200 on success; HTTP 207 if no connections created and errors exist.
     */
    public function run(): never
    {
        $raw  = file_get_contents('php://input');
        $data = json_decode($raw ?: '', true);

        $schema = null;
        if (is_array($data) && isset($data['schema']) && is_array($data['schema'])) {
            $schema = $data['schema'];
        }

        $engine = new AutoLinkEngine($this->db, $schema);
        $result = $engine->run();

        // Determine HTTP status code
        // HTTP 207 only when zero connections were created AND there are errors
        $httpCode = ($result['connections_created'] === 0 && count($result['errors']) > 0)
            ? 207
            : 200;

        jsonResponse($result, $httpCode);
    }
}
