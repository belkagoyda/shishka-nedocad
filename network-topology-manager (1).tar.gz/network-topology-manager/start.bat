@echo off
chcp 65001 >nul 2>&1
cd /d "%~dp0"

echo ============================================
echo  Network Topology Manager
echo ============================================
echo.

where php >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo ERROR: PHP not found in PATH.
    echo.
    echo Please install PHP 8.x with SQLite extension:
    echo   1. Download from https://www.php.net/downloads
    echo   2. Or use scoop:  scoop install php
    echo   3. Or use choco:  choco install php
    echo.
    echo Make sure php_pdo_sqlite.dll is enabled in php.ini:
    echo   extension=pdo_sqlite
    echo   extension=sqlite3
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('php -r "echo PHP_VERSION;" 2^>nul') do set PHP_VER=%%v
echo PHP version: %PHP_VER%

php -m 2>nul | findstr /i "pdo_sqlite" >nul
if %ERRORLEVEL% neq 0 (
    echo.
    echo WARNING: pdo_sqlite extension not loaded.
    echo Enable it in php.ini:
    echo   extension=pdo_sqlite
    echo   extension=sqlite3
    echo.
    pause
    exit /b 1
)

echo pdo_sqlite: OK
echo.

if not exist "db" mkdir db

set PORT=8000
if not "%1"=="" set PORT=%1

echo Starting server at http://localhost:%PORT%
echo.
echo Pages:
echo   http://localhost:%PORT%/models.html
echo   http://localhost:%PORT%/nodes.html
echo   http://localhost:%PORT%/connections.html
echo   http://localhost:%PORT%/topology.html
echo   http://localhost:%PORT%/settings.html
echo.
echo Press Ctrl+C to stop.
echo.

php -S localhost:%PORT% api/index.php
