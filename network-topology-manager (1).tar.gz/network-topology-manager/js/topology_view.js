/**
 * topology_view.js — загрузка данных, алгоритм компоновки и SVG-рендеринг топологии.
 *
 * Отвечает за:
 *   - Параллельную загрузку нод, связей и моделей через API
 *   - Построение карты моделей для O(1)-доступа
 *   - Вычисление размеров нод из модели (по умолчанию 40×12)
 *   - Алгоритм компоновки: группировка по rank, сортировка по cabinet-сегменту,
 *     вычисление координат прямоугольников
 *   - SVG-рендеринг нод (rect) и меток (text) на холсте 1920×1080
 *   - SVG-рендеринг связей как двухсегментных ломаных
 *   - Группировка по кабинетам: пунктирный <rect> вокруг нод с одинаковым cabinet-сегментом
 *   - Экспорт PDF через window.print() с CSS для A4 landscape
 *
 * Requirements: 6.1, 6.4, 6.5, 6.6, 6.7, 6.8, 6.9, 6.10, 6.11, 6.12, 6.13, 6.14
 */

import { parseName, DEFAULT_SCHEMA } from './name_parser.js';
import { getSchema } from './settings.js';

// ---------------------------------------------------------------------------
// Константы компоновки
// ---------------------------------------------------------------------------

/** Ширина ноды по умолчанию (px), если модель не задана или не содержит width */
export const DEFAULT_NODE_WIDTH = 40;

/** Высота ноды по умолчанию (px), если модель не задана или не содержит height */
export const DEFAULT_NODE_HEIGHT = 12;

/** Горизонтальный зазор между колонками (px) */
export const COLUMN_GAP = 60;

/** Вертикальный зазор между нодами внутри колонки (px) */
export const ROW_GAP = 16;

/** Отступ от левого края холста до первой колонки (px) */
export const PADDING_X = 20;

/** Отступ от верхнего края холста до первой ноды (px) */
export const PADDING_Y = 20;

/** Rank, присваиваемый ноде без модели (самый правый столбец) */
const DEFAULT_RANK = 10;

// ---------------------------------------------------------------------------
// API-загрузка
// ---------------------------------------------------------------------------

/**
 * Загружает ноды, связи и модели через API параллельно.
 *
 * @returns {Promise<{nodes: Array, connections: Array, models: Array}>}
 * @throws {Error} при ошибке сети или HTTP 5xx
 */
export async function loadTopologyData() {
  const [nodes, connections, models] = await Promise.all([
    fetchJson('/api/nodes'),
    fetchJson('/api/connections'),
    fetchJson('/api/models'),
  ]);
  return { nodes, connections, models };
}

/**
 * Вспомогательная функция: выполняет GET-запрос и возвращает JSON.
 *
 * @param {string} url
 * @returns {Promise<any>}
 */
async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || `HTTP ${response.status}`);
  }
  return response.json();
}

// ---------------------------------------------------------------------------
// Карта моделей
// ---------------------------------------------------------------------------

/**
 * Строит Map из id модели → объект модели для O(1)-доступа.
 *
 * @param {Array} models — массив объектов моделей
 * @returns {Map<number, Object>}
 */
export function buildModelMap(models) {
  const map = new Map();
  for (const model of models) {
    map.set(model.id, model);
  }
  return map;
}

// ---------------------------------------------------------------------------
// Размеры ноды
// ---------------------------------------------------------------------------

/**
 * Возвращает размеры прямоугольника ноды из её модели.
 * Если модель не найдена или не содержит корректных размеров — возвращает значения по умолчанию.
 *
 * @param {Object} node — объект ноды (должен содержать model_id)
 * @param {Map<number, Object>} modelMap — карта id → модель
 * @returns {{ width: number, height: number }}
 */
export function getNodeDimensions(node, modelMap) {
  const model = node.model_id != null ? modelMap.get(node.model_id) : undefined;
  const width = (model && model.width > 0) ? model.width : DEFAULT_NODE_WIDTH;
  const height = (model && model.height > 0) ? model.height : DEFAULT_NODE_HEIGHT;
  return { width, height };
}

// ---------------------------------------------------------------------------
// Cabinet-сегмент
// ---------------------------------------------------------------------------

/**
 * Извлекает cabinet-сегмент из имени ноды по заданной схеме.
 * Возвращает пустую строку, если сегмент отсутствует.
 *
 * @param {string} name — имя ноды
 * @param {string[]} schema — схема сегментов (например, ['building','floor','cabinet','device'])
 * @returns {string}
 */
export function getCabinetSegment(name, schema) {
  const parsed = parseName(name, schema);
  return parsed.cabinet ?? '';
}

// ---------------------------------------------------------------------------
// Алгоритм компоновки
// ---------------------------------------------------------------------------

/**
 * Основной алгоритм компоновки нод.
 *
 * 1. Группирует ноды по rank (из модели; если модели нет — rank = DEFAULT_RANK).
 * 2. Сортирует группы по возрастанию rank (слева направо).
 * 3. Внутри каждой группы сортирует ноды по cabinet-сегменту лексикографически.
 * 4. Вычисляет x, y координаты для каждого прямоугольника ноды.
 *
 * Правила вычисления координат:
 *   - Первая колонка начинается с x = PADDING_X
 *   - Каждая следующая колонка: x += (max_width_в_предыдущей_колонке + COLUMN_GAP)
 *   - Первая нода в колонке: y = PADDING_Y
 *   - Каждая следующая нода: y += (высота_предыдущей_ноды + ROW_GAP)
 *
 * @param {Array} nodes — массив объектов нод
 * @param {Map<number, Object>} modelMap — карта id → модель
 * @param {string[]} [schema=DEFAULT_SCHEMA] — схема сегментов для парсинга имён
 * @returns {Array<{node: Object, x: number, y: number, width: number, height: number}>}
 */
export function layoutNodes(nodes, modelMap, schema = DEFAULT_SCHEMA) {
  // 1. Группировка по rank
  /** @type {Map<number, Array>} */
  const rankGroups = new Map();

  for (const node of nodes) {
    const model = node.model_id != null ? modelMap.get(node.model_id) : undefined;
    const rank = (model != null && model.rank != null) ? model.rank : DEFAULT_RANK;

    if (!rankGroups.has(rank)) {
      rankGroups.set(rank, []);
    }
    rankGroups.get(rank).push(node);
  }

  // 2. Сортировка групп по возрастанию rank
  const sortedRanks = Array.from(rankGroups.keys()).sort((a, b) => a - b);

  // 3. Вычисление координат
  const layoutItems = [];
  let currentX = PADDING_X;

  for (const rank of sortedRanks) {
    const group = rankGroups.get(rank);

    // Сортировка нод внутри колонки по cabinet-сегменту (лексикографически)
    group.sort((a, b) => {
      const cabinetA = getCabinetSegment(a.name ?? '', schema);
      const cabinetB = getCabinetSegment(b.name ?? '', schema);
      if (cabinetA < cabinetB) return -1;
      if (cabinetA > cabinetB) return 1;
      // Вторичная сортировка по имени для детерминизма
      return (a.name ?? '') < (b.name ?? '') ? -1 : (a.name ?? '') > (b.name ?? '') ? 1 : 0;
    });

    // Определяем максимальную ширину в колонке (для вычисления x следующей колонки)
    let maxWidth = 0;
    let currentY = PADDING_Y;

    for (const node of group) {
      const { width, height } = getNodeDimensions(node, modelMap);
      if (width > maxWidth) maxWidth = width;

      layoutItems.push({ node, x: currentX, y: currentY, width, height });

      currentY += height + ROW_GAP;
    }

    // Сдвигаем x для следующей колонки
    currentX += maxWidth + COLUMN_GAP;
  }

  return layoutItems;
}

// ---------------------------------------------------------------------------
// Оркестратор компоновки
// ---------------------------------------------------------------------------

/**
 * Оркестрирует полную компоновку: строит карту моделей и вычисляет позиции нод.
 *
 * @param {Array} nodes — массив объектов нод
 * @param {Array} connections — массив объектов связей
 * @param {Array} models — массив объектов моделей
 * @param {string[]} [schema] — схема сегментов; если не передана — читается из getSchema()
 * @returns {{ layoutItems: Array, connections: Array, modelMap: Map }}
 */
export function computeLayout(nodes, connections, models, schema) {
  const resolvedSchema = schema ?? getSchema();
  const modelMap = buildModelMap(models);
  const layoutItems = layoutNodes(nodes, modelMap, resolvedSchema);
  return { layoutItems, connections, modelMap };
}

// ---------------------------------------------------------------------------
// SVG-рендеринг нод и меток (Requirements: 6.1, 6.6, 6.7, 6.8)
// ---------------------------------------------------------------------------

/** SVG namespace URI */
const SVG_NS = 'http://www.w3.org/2000/svg';

/** Фиксированная логическая ширина SVG-холста (px) */
export const SVG_WIDTH = 1920;

/** Фиксированная логическая высота SVG-холста (px) */
export const SVG_HEIGHT = 1080;

/**
 * Создаёт SVG-элемент с фиксированными размерами 1920×1080.
 *
 * @returns {SVGSVGElement}
 */
export function createSvgCanvas() {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('width', String(SVG_WIDTH));
  svg.setAttribute('height', String(SVG_HEIGHT));
  svg.setAttribute('viewBox', `0 0 ${SVG_WIDTH} ${SVG_HEIGHT}`);
  svg.setAttribute('xmlns', SVG_NS);
  return svg;
}

/**
 * Определяет метку для ноды согласно правилу:
 *   - Если в имени присутствует cabinet-сегмент (≥3 сегментов по схеме по умолчанию),
 *     возвращает device-сегмент (последний сегмент имени).
 *   - Иначе возвращает первые 6 символов имени.
 *
 * @param {string} name — имя ноды
 * @param {string[]} [schema=DEFAULT_SCHEMA] — схема сегментов
 * @returns {string}
 */
export function getNodeLabel(name, schema = DEFAULT_SCHEMA) {
  const parsed = parseName(name, schema);
  if (parsed.cabinet !== undefined) {
    // cabinet-сегмент присутствует — показываем device-сегмент (последний сегмент имени)
    const parts = name.split('-');
    return parts[parts.length - 1];
  }
  // cabinet-сегмент отсутствует — первые 6 символов имени
  return (name ?? '').slice(0, 6);
}

/**
 * Отрисовывает ноды и их метки на SVG-холсте.
 *
 * Для каждого элемента компоновки:
 *   - Добавляет `<rect>` с координатами и размерами из layoutItem
 *   - Добавляет `<text>` с меткой, расположенной на 8pt выше прямоугольника
 *
 * @param {SVGSVGElement} svg — SVG-элемент, созданный через createSvgCanvas()
 * @param {Array<{node: Object, x: number, y: number, width: number, height: number}>} layoutItems
 * @param {string[]} [schema=DEFAULT_SCHEMA] — схема сегментов для определения метки
 */
export function renderNodes(svg, layoutItems, schema = DEFAULT_SCHEMA) {
  for (const item of layoutItems) {
    const { node, x, y, width, height } = item;

    // --- <rect> для ноды ---
    const rect = document.createElementNS(SVG_NS, 'rect');
    rect.setAttribute('x', String(x));
    rect.setAttribute('y', String(y));
    rect.setAttribute('width', String(width));
    rect.setAttribute('height', String(height));
    rect.setAttribute('fill', 'none');
    rect.setAttribute('stroke', '#333333');
    rect.setAttribute('stroke-width', '1');
    svg.appendChild(rect);

    // --- <text> метки над прямоугольником ---
    const label = getNodeLabel(node.name ?? '', schema);
    const text = document.createElementNS(SVG_NS, 'text');
    // Позиционируем текст горизонтально по центру прямоугольника,
    // вертикально — на 2px выше верхней границы прямоугольника
    text.setAttribute('x', String(x + width / 2));
    text.setAttribute('y', String(y - 2));
    text.setAttribute('font-size', '8pt');
    text.setAttribute('text-anchor', 'middle');
    text.setAttribute('dominant-baseline', 'auto');
    text.textContent = label;
    svg.appendChild(text);
  }
}

// ---------------------------------------------------------------------------
// Карта позиций нод (Requirements: 6.9, 6.10)
// ---------------------------------------------------------------------------

/**
 * Строит Map из node.id → элемент компоновки для O(1)-доступа при рендеринге связей.
 *
 * @param {Array<{node: Object, x: number, y: number, width: number, height: number}>} layoutItems
 * @returns {Map<number|string, {node: Object, x: number, y: number, width: number, height: number}>}
 */
export function buildNodePositionMap(layoutItems) {
  const map = new Map();
  for (const item of layoutItems) {
    map.set(item.node.id, item);
  }
  return map;
}

// ---------------------------------------------------------------------------
// SVG-рендеринг связей (Requirements: 6.9, 6.10)
// ---------------------------------------------------------------------------

/**
 * Отрисовывает связи на SVG-холсте как двухсегментные ломаные (L-образные).
 *
 * Для каждой связи строится `<polyline>` из трёх точек:
 *   1. (srcRight, srcMidY)  — правый край источника
 *   2. (dstLeft,  srcMidY)  — горизонтальный сегмент до x назначения
 *   3. (dstLeft,  dstMidY)  — вертикальный сегмент до центра назначения
 *
 * Это даёт ровно два сегмента: один горизонтальный и один вертикальный изгиб.
 *
 * Атрибуты линии:
 *   - `stroke`        = colour_line (по умолчанию #000000)
 *   - `fill`          = none
 *   - `stroke-width`  = 1 (normal/dashed), 0.5 (thin), 2 (thick)
 *   - `stroke-dasharray` = "4,4" только для type_line === 'dashed'
 *
 * @param {SVGSVGElement} svg — SVG-элемент, созданный через createSvgCanvas()
 * @param {Array<{id: number, src_node_id: number, dst_node_id: number, type_line: string, colour_line: string}>} connections
 * @param {Map<number|string, {node: Object, x: number, y: number, width: number, height: number}>} nodePositionMap
 */
export function renderConnections(svg, connections, nodePositionMap) {
  for (const conn of connections) {
    const src = nodePositionMap.get(conn.src_node_id);
    const dst = nodePositionMap.get(conn.dst_node_id);

    // Пропускаем связи, у которых нет позиции для одного из узлов
    if (!src || !dst) continue;

    // Координаты ключевых точек
    const srcRight = src.x + src.width;
    const srcMidY  = src.y + src.height / 2;
    const dstLeft  = dst.x;
    const dstMidY  = dst.y + dst.height / 2;

    // Строка points для <polyline>: три точки, два сегмента
    const points = `${srcRight},${srcMidY} ${dstLeft},${srcMidY} ${dstLeft},${dstMidY}`;

    // Определяем стиль линии по type_line
    const typeLine    = conn.type_line   ?? 'normal';
    const colourLine  = conn.colour_line ?? '#000000';

    let strokeWidth;
    switch (typeLine) {
      case 'thin':  strokeWidth = '0.5'; break;
      case 'thick': strokeWidth = '2';   break;
      default:      strokeWidth = '1';   break; // normal и dashed
    }

    // Use the svg element's createElementNS if available (supports test stubs),
    // otherwise fall back to the global document.
    const createEl = svg.createElementNS
      ? (ns, tag) => svg.createElementNS(ns, tag)
      : (ns, tag) => document.createElementNS(ns, tag);
    const polyline = createEl(SVG_NS, 'polyline');
    polyline.setAttribute('points',       points);
    polyline.setAttribute('stroke',       colourLine);
    polyline.setAttribute('fill',         'none');
    polyline.setAttribute('stroke-width', strokeWidth);

    if (typeLine === 'dashed') {
      polyline.setAttribute('stroke-dasharray', '4,4');
    }

    svg.appendChild(polyline);
  }
}

// ---------------------------------------------------------------------------
// Группировка по кабинетам (Requirements: 6.12, 6.13)
// ---------------------------------------------------------------------------

/** Отступ вокруг группы нод при рисовании пунктирного прямоугольника (px) */
export const CABINET_GROUP_PADDING = 4;

/**
 * Вариант layoutNodes с явной группировкой по кабинетам внутри каждой rank-колонки.
 *
 * Алгоритм идентичен layoutNodes (ноды уже сортируются по cabinet-сегменту),
 * но функция явно документирована как «grouped» вариант для использования
 * при включённом чекбоксе «Группировка по кабинетам».
 *
 * При включённой группировке ноды внутри каждого cabinet-сегмента располагаются
 * вертикально (что уже обеспечивается сортировкой по cabinet в layoutNodes).
 *
 * @param {Array} nodes — массив объектов нод
 * @param {Map<number, Object>} modelMap — карта id → модель
 * @param {string[]} [schema=DEFAULT_SCHEMA] — схема сегментов для парсинга имён
 * @returns {Array<{node: Object, x: number, y: number, width: number, height: number}>}
 *
 * Requirements: 6.13
 */
export function layoutNodesGrouped(nodes, modelMap, schema = DEFAULT_SCHEMA) {
  // Delegates to layoutNodes — cabinet-sorting is already applied there,
  // which arranges nodes within each cabinet group vertically.
  return layoutNodes(nodes, modelMap, schema);
}

/**
 * Отрисовывает пунктирные прямоугольники вокруг групп нод с одинаковым cabinet-сегментом.
 *
 * Для каждой уникальной пары (cabinet, rank-колонка) вычисляет bounding box всех нод
 * группы и рисует `<rect>` с отступом CABINET_GROUP_PADDING со всех сторон.
 *
 * Атрибуты прямоугольника:
 *   - `stroke-dasharray` = "4,4"
 *   - `fill`             = "none"
 *   - `stroke`           = "#666666"
 *   - `stroke-width`     = "1"
 *
 * Ноды без cabinet-сегмента (cabinet === '') не группируются и не обводятся.
 *
 * Рекомендуемый CSS для страницы топологии (для поддержки экспорта PDF):
 * ```css
 * \@media print {
 *   \@page { size: A4 landscape; }
 * }
 * ```
 *
 * @param {SVGSVGElement} svg — SVG-элемент, созданный через createSvgCanvas()
 * @param {Array<{node: Object, x: number, y: number, width: number, height: number}>} layoutItems
 * @param {string[]} [schema=DEFAULT_SCHEMA] — схема сегментов для парсинга имён
 *
 * Requirements: 6.12
 */
export function renderCabinetGroups(svg, layoutItems, schema = DEFAULT_SCHEMA) {
  // Build a map: cabinetKey → array of layoutItems
  // cabinetKey = "<cabinet>@<x>" — unique per cabinet within a rank column
  // (nodes in the same rank column share the same x-coordinate)
  /** @type {Map<string, Array>} */
  const groups = new Map();

  for (const item of layoutItems) {
    const cabinet = getCabinetSegment(item.node.name ?? '', schema);
    if (cabinet === '') continue; // skip nodes without a cabinet segment

    // Use cabinet + x-coordinate as the group key so that nodes in different
    // rank columns with the same cabinet name are treated as separate groups.
    const key = `${cabinet}@${item.x}`;
    if (!groups.has(key)) {
      groups.set(key, []);
    }
    groups.get(key).push(item);
  }

  // Draw a dashed rect around each group
  const createEl = svg.createElementNS
    ? (ns, tag) => svg.createElementNS(ns, tag)
    : (ns, tag) => document.createElementNS(ns, tag);

  for (const items of groups.values()) {
    if (items.length === 0) continue;

    // Compute bounding box
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;

    for (const item of items) {
      if (item.x < minX) minX = item.x;
      if (item.y < minY) minY = item.y;
      if (item.x + item.width > maxX) maxX = item.x + item.width;
      if (item.y + item.height > maxY) maxY = item.y + item.height;
    }

    // Apply padding
    const rectX = minX - CABINET_GROUP_PADDING;
    const rectY = minY - CABINET_GROUP_PADDING;
    const rectW = (maxX - minX) + CABINET_GROUP_PADDING * 2;
    const rectH = (maxY - minY) + CABINET_GROUP_PADDING * 2;

    const rect = createEl(SVG_NS, 'rect');
    rect.setAttribute('x',                String(rectX));
    rect.setAttribute('y',                String(rectY));
    rect.setAttribute('width',            String(rectW));
    rect.setAttribute('height',           String(rectH));
    rect.setAttribute('fill',             'none');
    rect.setAttribute('stroke',           '#666666');
    rect.setAttribute('stroke-width',     '1');
    rect.setAttribute('stroke-dasharray', '4,4');

    svg.appendChild(rect);
  }
}

// ---------------------------------------------------------------------------
// Экспорт PDF (Requirement: 6.14)
// ---------------------------------------------------------------------------

/**
 * Вызывает браузерный диалог печати для экспорта топологии в PDF.
 *
 * Для корректного форматирования страница топологии должна включать следующий CSS:
 * ```css
 * \@media print {
 *   \@page { size: A4 landscape; }
 *   body  { margin: 0; }
 * }
 * ```
 *
 * Этот CSS обеспечивает:
 *   - Ориентацию A4 landscape при печати/сохранении в PDF
 *   - Отсутствие лишних отступов вокруг SVG-схемы
 *
 * @returns {void}
 *
 * Requirements: 6.14
 */
export function triggerPdfExport() {
  window.print();
}
