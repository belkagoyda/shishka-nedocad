/**
 * models.js — управление каталогом моделей оборудования.
 *
 * Экспортирует функции для загрузки, рендеринга и отправки моделей.
 * Использует fetch() для взаимодействия с API.
 *
 * Requirements: 1.7, 1.8, 1.9
 */

const API_URL = '/api/models';

/** Допустимые значения типа модели */
export const MODEL_TYPES = ['router', 'switch_dist', 'switch_access', 'pc', 'printer'];

/**
 * Загружает список моделей через GET /api/models.
 *
 * @returns {Promise<Array>} — массив объектов моделей
 * @throws {Error} при ошибке сети или HTTP 5xx
 */
export async function loadModels() {
  const response = await fetch(API_URL);
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || `HTTP ${response.status}`);
  }
  return response.json();
}

/**
 * Создаёт новую модель через POST /api/models.
 *
 * @param {Object} data — поля модели: name, type, rank, width, height
 * @returns {Promise<Object>} — созданная запись
 * @throws {Error} при ошибке сети; при HTTP 4xx возвращает объект с полем error
 */
export async function createModel(data) {
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const err = new Error(body.error || `HTTP ${response.status}`);
    err.apiError = body.error || `HTTP ${response.status}`;
    err.status = response.status;
    throw err;
  }
  return body;
}

/**
 * Обновляет модель через PUT /api/models/:id.
 *
 * @param {number} id
 * @param {Object} data
 * @returns {Promise<Object>} — обновлённая запись
 */
export async function updateModel(id, data) {
  const response = await fetch(`${API_URL}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const err = new Error(body.error || `HTTP ${response.status}`);
    err.apiError = body.error || `HTTP ${response.status}`;
    err.status = response.status;
    throw err;
  }
  return body;
}

/**
 * Удаляет модель через DELETE /api/models/:id.
 *
 * @param {number} id
 * @returns {Promise<void>}
 */
export async function deleteModel(id) {
  const response = await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || `HTTP ${response.status}`);
  }
}

/**
 * Создаёт строку таблицы для существующей модели (режим просмотра).
 *
 * @param {Object} model
 * @param {Function} onEdit — callback при нажатии Edit
 * @param {Function} onDelete — callback при нажатии Delete
 * @returns {HTMLTableRowElement}
 */
function createModelRow(model, onEdit, onDelete) {
  const tr = document.createElement('tr');
  tr.dataset.id = model.id;

  const fields = ['name', 'type', 'rank', 'width', 'height'];
  fields.forEach((field) => {
    const td = document.createElement('td');
    td.textContent = model[field] ?? '';
    tr.appendChild(td);
  });

  // Actions cell
  const tdActions = document.createElement('td');

  const btnEdit = document.createElement('button');
  btnEdit.textContent = 'Ред.';
  btnEdit.addEventListener('click', () => onEdit(tr, model));

  const btnDelete = document.createElement('button');
  btnDelete.textContent = 'Удал.';
  btnDelete.addEventListener('click', () => onDelete(model.id, tr));

  tdActions.appendChild(btnEdit);
  tdActions.appendChild(btnDelete);
  tr.appendChild(tdActions);

  return tr;
}

/**
 * Создаёт строку таблицы в режиме редактирования для существующей модели.
 *
 * @param {Object} model
 * @param {Function} onSave — callback при нажатии Save
 * @param {Function} onCancel — callback при нажатии Cancel
 * @returns {HTMLTableRowElement}
 */
function createEditRow(model, onSave, onCancel) {
  const tr = document.createElement('tr');
  tr.dataset.id = model.id;
  tr.dataset.editRow = 'true';

  // name
  const tdName = document.createElement('td');
  const inputName = document.createElement('input');
  inputName.type = 'text';
  inputName.value = model.name || '';
  inputName.dataset.field = 'name';
  const errName = document.createElement('span');
  errName.className = 'field-error';
  tdName.appendChild(inputName);
  tdName.appendChild(errName);
  tr.appendChild(tdName);

  // type
  const tdType = document.createElement('td');
  const selectType = document.createElement('select');
  selectType.dataset.field = 'type';
  MODEL_TYPES.forEach((t) => {
    const opt = document.createElement('option');
    opt.value = t;
    opt.textContent = t;
    if (t === model.type) opt.selected = true;
    selectType.appendChild(opt);
  });
  const errType = document.createElement('span');
  errType.className = 'field-error';
  tdType.appendChild(selectType);
  tdType.appendChild(errType);
  tr.appendChild(tdType);

  // rank
  const tdRank = document.createElement('td');
  const inputRank = document.createElement('input');
  inputRank.type = 'number';
  inputRank.min = '0';
  inputRank.max = '10';
  inputRank.value = model.rank ?? '';
  inputRank.dataset.field = 'rank';
  const errRank = document.createElement('span');
  errRank.className = 'field-error';
  tdRank.appendChild(inputRank);
  tdRank.appendChild(errRank);
  tr.appendChild(tdRank);

  // width
  const tdWidth = document.createElement('td');
  const inputWidth = document.createElement('input');
  inputWidth.type = 'number';
  inputWidth.value = model.width ?? '';
  inputWidth.dataset.field = 'width';
  const errWidth = document.createElement('span');
  errWidth.className = 'field-error';
  tdWidth.appendChild(inputWidth);
  tdWidth.appendChild(errWidth);
  tr.appendChild(tdWidth);

  // height
  const tdHeight = document.createElement('td');
  const inputHeight = document.createElement('input');
  inputHeight.type = 'number';
  inputHeight.value = model.height ?? '';
  inputHeight.dataset.field = 'height';
  const errHeight = document.createElement('span');
  errHeight.className = 'field-error';
  tdHeight.appendChild(inputHeight);
  tdHeight.appendChild(errHeight);
  tr.appendChild(tdHeight);

  // Actions
  const tdActions = document.createElement('td');
  const btnSave = document.createElement('button');
  btnSave.textContent = 'Сохр.';
  btnSave.addEventListener('click', () => onSave(tr));

  const btnCancel = document.createElement('button');
  btnCancel.textContent = 'Отмена';
  btnCancel.addEventListener('click', () => onCancel(tr, model));

  tdActions.appendChild(btnSave);
  tdActions.appendChild(btnCancel);
  tr.appendChild(tdActions);

  return tr;
}

/**
 * Создаёт пустую редактируемую строку для добавления новой модели.
 *
 * @param {Function} onSave — callback при нажатии Save
 * @returns {HTMLTableRowElement}
 */
export function createNewRow(onSave) {
  const tr = document.createElement('tr');
  tr.dataset.newRow = 'true';

  // name
  const tdName = document.createElement('td');
  const inputName = document.createElement('input');
  inputName.type = 'text';
  inputName.value = '';
  inputName.placeholder = 'Название';
  inputName.dataset.field = 'name';
  const errName = document.createElement('span');
  errName.className = 'field-error';
  tdName.appendChild(inputName);
  tdName.appendChild(errName);
  tr.appendChild(tdName);

  // type
  const tdType = document.createElement('td');
  const selectType = document.createElement('select');
  selectType.dataset.field = 'type';
  MODEL_TYPES.forEach((t) => {
    const opt = document.createElement('option');
    opt.value = t;
    opt.textContent = t;
    selectType.appendChild(opt);
  });
  const errType = document.createElement('span');
  errType.className = 'field-error';
  tdType.appendChild(selectType);
  tdType.appendChild(errType);
  tr.appendChild(tdType);

  // rank
  const tdRank = document.createElement('td');
  const inputRank = document.createElement('input');
  inputRank.type = 'number';
  inputRank.min = '0';
  inputRank.max = '10';
  inputRank.value = '';
  inputRank.placeholder = '0–10';
  inputRank.dataset.field = 'rank';
  const errRank = document.createElement('span');
  errRank.className = 'field-error';
  tdRank.appendChild(inputRank);
  tdRank.appendChild(errRank);
  tr.appendChild(tdRank);

  // width
  const tdWidth = document.createElement('td');
  const inputWidth = document.createElement('input');
  inputWidth.type = 'number';
  inputWidth.value = '';
  inputWidth.placeholder = '40';
  inputWidth.dataset.field = 'width';
  const errWidth = document.createElement('span');
  errWidth.className = 'field-error';
  tdWidth.appendChild(inputWidth);
  tdWidth.appendChild(errWidth);
  tr.appendChild(tdWidth);

  // height
  const tdHeight = document.createElement('td');
  const inputHeight = document.createElement('input');
  inputHeight.type = 'number';
  inputHeight.value = '';
  inputHeight.placeholder = '12';
  inputHeight.dataset.field = 'height';
  const errHeight = document.createElement('span');
  errHeight.className = 'field-error';
  tdHeight.appendChild(inputHeight);
  tdHeight.appendChild(errHeight);
  tr.appendChild(tdHeight);

  // Actions
  const tdActions = document.createElement('td');
  const btnSave = document.createElement('button');
  btnSave.textContent = 'Сохр.';
  btnSave.addEventListener('click', () => onSave(tr));
  tdActions.appendChild(btnSave);
  tr.appendChild(tdActions);

  return tr;
}

/**
 * Считывает данные из строки таблицы (редактируемой или новой).
 *
 * @param {HTMLTableRowElement} tr
 * @returns {Object} — объект с полями name, type, rank, width, height
 */
function collectRowData(tr) {
  const data = {};
  tr.querySelectorAll('[data-field]').forEach((el) => {
    const field = el.dataset.field;
    const value = el.value.trim();
    if (field === 'rank' || field === 'width' || field === 'height') {
      data[field] = value === '' ? undefined : Number(value);
    } else {
      data[field] = value;
    }
  });
  return data;
}

/**
 * Очищает все ошибки в строке таблицы.
 *
 * @param {HTMLTableRowElement} tr
 */
function clearRowErrors(tr) {
  tr.querySelectorAll('.field-error').forEach((el) => {
    el.textContent = '';
  });
}

/**
 * Определяет имя поля из сообщения об ошибке API.
 * Примеры: "Field 'type' is required" → 'type', "Invalid value 'X' for field 'rank'" → 'rank'
 */
function detectErrorField(errorMessage) {
  const match1 = errorMessage.match(/Field '(\w+)'/i);
  if (match1) return match1[1];
  const match2 = errorMessage.match(/for field '(\w+)'/i);
  if (match2) return match2[1];
  return 'name';
}

/**
 * Показывает текст ошибки рядом с конкретным полем формы.
 */
function showFieldError(tr, fieldName, message) {
  const target = tr.querySelector(`[data-field="${fieldName}"]`);
  if (target) {
    const errSpan = target.parentElement.querySelector('.field-error');
    if (errSpan) errSpan.textContent = message;
  }
}

/**
 * Отображает ошибку API рядом с соответствующим полем формы.
 * Если поле из сообщения не найдено в строке — показываем на name.
 */
function showApiError(tr, errorMessage) {
  const field = detectErrorField(errorMessage);
  const target = tr.querySelector(`[data-field="${field}"]`);
  if (target) {
    const errSpan = target.parentElement.querySelector('.field-error');
    if (errSpan) { errSpan.textContent = errorMessage; return; }
  }
  showFieldError(tr, 'name', errorMessage);
}

/**
 * Рендерит таблицу моделей в указанный tbody.
 * Добавляет строки для каждой модели и пустую редактируемую строку в конце.
 *
 * @param {Array} models — массив объектов моделей
 * @param {HTMLTableSectionElement} tbody — элемент tbody таблицы
 * @param {Function} onRefresh — callback для обновления таблицы (перезагрузка данных)
 */
export function renderModels(models, tbody, onRefresh) {
  tbody.innerHTML = '';

  models.forEach((model) => {
      const onEdit = (tr, m) => {
      const editRow = createEditRow(
        m,
        async (editTr) => {
          clearRowErrors(editTr);
          const data = collectRowData(editTr);
          try {
            await updateModel(m.id, data);
            if (onRefresh) onRefresh();
          } catch (err) {
            showApiError(editTr, err.apiError || err.message);
          }
        },
        (editTr, original) => {
          const viewRow = createModelRow(original, onEdit, onDeleteHandler);
          editTr.replaceWith(viewRow);
        },
      );
      tr.replaceWith(editRow);
    };

    const onDeleteHandler = async (id, tr) => {
      try {
        await deleteModel(id);
        tr.remove();
      } catch (err) {
        alert(err.message);
      }
    };

    const row = createModelRow(model, onEdit, onDeleteHandler);
    tbody.appendChild(row);
  });

  // Пустая редактируемая строка в конце таблицы
  const newRow = createNewRow(async (tr) => {
    clearRowErrors(tr);
    const data = collectRowData(tr);
    try {
      await createModel(data);
      if (onRefresh) onRefresh();
    } catch (err) {
      showApiError(tr, err.apiError || err.message);
    }
  });
  tbody.appendChild(newRow);
}

/**
 * Инициализирует страницу каталога моделей.
 * Загружает данные и рендерит таблицу.
 *
 * @param {HTMLTableSectionElement} tbody
 * @param {HTMLElement} errorContainer — элемент для отображения глобальных ошибок
 */
export async function initModelsPage(tbody, errorContainer) {
  const refresh = async () => {
    try {
      const models = await loadModels();
      renderModels(models, tbody, refresh);
    } catch (err) {
      if (errorContainer) {
        errorContainer.textContent = `Ошибка загрузки: ${err.message}`;
      }
    }
  };

  await refresh();
}
