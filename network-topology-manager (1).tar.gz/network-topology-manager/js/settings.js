/**
 * Settings — управление Parse_Schema (localStorage).
 *
 * Схема хранится в localStorage под ключом `parseSchema` как JSON-массив строк.
 * Схема по умолчанию: ['building', 'floor', 'cabinet', 'device']
 */

/** Ключ хранилища */
const STORAGE_KEY = 'parseSchema';

/** Схема по умолчанию */
export const DEFAULT_SCHEMA = ['building', 'floor', 'cabinet', 'device'];

/**
 * Читает Parse_Schema из localStorage.
 * Если ключ отсутствует или значение невалидно — возвращает схему по умолчанию.
 *
 * @returns {string[]} — массив меток сегментов
 */
export function getSchema() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw === null) {
      return [...DEFAULT_SCHEMA];
    }
    const parsed = JSON.parse(raw);
    if (
      Array.isArray(parsed) &&
      parsed.length > 0 &&
      parsed.every((s) => typeof s === 'string' && s.length > 0)
    ) {
      return parsed;
    }
    return [...DEFAULT_SCHEMA];
  } catch {
    return [...DEFAULT_SCHEMA];
  }
}

/**
 * Сохраняет Parse_Schema в localStorage.
 *
 * @param {string[]} segments — непустой массив непустых строк
 * @throws {Error} если segments не является непустым массивом непустых строк
 */
export function saveSchema(segments) {
  if (
    !Array.isArray(segments) ||
    segments.length === 0 ||
    !segments.every((s) => typeof s === 'string' && s.length > 0)
  ) {
    throw new Error('segments must be a non-empty array of non-empty strings');
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(segments));
}
