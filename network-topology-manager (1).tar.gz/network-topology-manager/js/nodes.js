/**
 * nodes.js — управление реестром сетевых устройств (нод).
 *
 * Экспортирует функции для загрузки, рендеринга и отправки нод.
 * Использует fetch() для взаимодействия с API.
 * Подключает name_parser.js для отображения разобранных сегментов имени.
 *
 * Requirements: 2.6, 2.7, 2.8
 */

import { parseName } from './name_parser.js';

const API_URL = '/api/nodes';
const MODELS_API_URL = '/api/models';

/** Допустимые значения типа ноды */
export const NODE_TYPES = ['router', 'switch_dist', 'switch_access', 'pc', 'printer'];

/**
 * Загружает список нод через GET /api/nodes.
 *
 * @returns {Promise<Array>} — массив объектов нод
 * @throws {Error} при ошибке сети или HTTP 5xx
 */
export async function loadNodes() {
  const response = await fetch(API_URL);
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || `HTTP ${response.status}`);
  }
  return response.json();
}

/**
 * Загружает список моделей через GET /api/models.
 *
 * @returns {Promise<Array>} — массив объектов моделей
 * @throws {Error} при ошибке сети или HTTP 5xx
 */
export async function loadModels() {
  const response = await fetch(MODELS_API_URL);
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || `HTTP ${response.status}`);
  }
  return response.json();
}

/**
 * Создаёт новую ноду через POST /api/nodes.
 *
 * @param {Object} data — поля ноды: name, type, model_id, ip, mac
 * @returns {Promise<Object>} — созданная запись
 * @throws {Error} при ошибке сети; при HTTP 4xx возвращает объект с полем error
 */
export async function createNode(data) {
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const err = new Error(body.error || `HTTP ${response.status}`);
    err.apiError = body.error || `HTTP ${response.status}`;
    err.status = response.status;
    throw err;
  }
  return body;
}

/**
 * Обновляет ноду через PUT /api/nodes/:id.
 *
 * @param {number} id
 * @param {Object} data
 * @returns {Promise<Object>} — обновлённая запись
 */
export async function updateNode(id, data) {
  const response = await fetch(`${API_URL}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const err = new Error(body.error || `HTTP ${response.status}`);
    err.apiError = body.error || `HTTP ${response.status}`;
    err.status = response.status;
    throw err;
  }
  return body;
}

/**
 * Удаляет ноду через DELETE /api/nodes/:id.
 *
 * @param {number} id
 * @returns {Promise<void>}
 */
export async function deleteNode(id) {
  const response = await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || `HTTP ${response.status}`);
  }
}

/**
 * Форматирует результат parseName в строку «key:value» через пробел.
 *
 * @param {string} name — имя ноды
 * @param {string[]} schema — схема сегментов
 * @returns {string} — строка вида «building:B1 floor:2 cabinet:301 device:PC01»
 */
function formatParsedName(name, schema) {
  const parsed = parseName(name, schema);
  return Object.entries(parsed)
    .map(([k, v]) => `${k}:${v}`)
    .join(' ');
}

/**
 * Находит имя модели по её id.
 *
 * @param {Array} models — массив объектов моделей
 * @param {number|null} modelId
 * @returns {string}
 */
function getModelName(models, modelId) {
  if (modelId == null) return '';
  const model = models.find((m) => m.id === modelId);
  return model ? model.name : String(modelId);
}

/**
 * Создаёт строку таблицы для существующей ноды (режим просмотра).
 *
 * @param {Object} node
 * @param {Array} models — массив объектов моделей
 * @param {string[]} schema — схема сегментов
 * @param {Function} onEdit — callback при нажатии Edit
 * @param {Function} onDelete — callback при нажатии Delete
 * @returns {HTMLTableRowElement}
 */
function createNodeRow(node, models, schema, onEdit, onDelete) {
  const tr = document.createElement('tr');
  tr.dataset.id = node.id;

  // name
  const tdName = document.createElement('td');
  tdName.textContent = node.name ?? '';
  tr.appendChild(tdName);

  // parsed name
  const tdParsed = document.createElement('td');
  tdParsed.className = 'parsed-name-cell';
  tdParsed.textContent = node.name ? formatParsedName(node.name, schema) : '';
  tr.appendChild(tdParsed);

  // type
  const tdType = document.createElement('td');
  tdType.textContent = node.type ?? '';
  tr.appendChild(tdType);

  // model
  const tdModel = document.createElement('td');
  tdModel.textContent = getModelName(models, node.model_id);
  tr.appendChild(tdModel);

  // ip
  const tdIp = document.createElement('td');
  tdIp.textContent = node.ip ?? '';
  tr.appendChild(tdIp);

  // mac
  const tdMac = document.createElement('td');
  tdMac.textContent = node.mac ?? '';
  tr.appendChild(tdMac);

  // Actions cell
  const tdActions = document.createElement('td');

  const btnEdit = document.createElement('button');
  btnEdit.textContent = 'Ред.';
  btnEdit.addEventListener('click', () => onEdit(tr, node));

  const btnDelete = document.createElement('button');
  btnDelete.textContent = 'Удал.';
  btnDelete.addEventListener('click', () => onDelete(node.id, tr));

  tdActions.appendChild(btnEdit);
  tdActions.appendChild(btnDelete);
  tr.appendChild(tdActions);

  return tr;
}

/**
 * Создаёт строку таблицы в режиме редактирования для существующей ноды.
 *
 * @param {Object} node
 * @param {Array} models — массив объектов моделей
 * @param {string[]} schema — схема сегментов
 * @param {Function} onSave — callback при нажатии Save
 * @param {Function} onCancel — callback при нажатии Cancel
 * @returns {HTMLTableRowElement}
 */
function createEditNodeRow(node, models, schema, onSave, onCancel) {
  const tr = document.createElement('tr');
  tr.dataset.id = node.id;
  tr.dataset.editRow = 'true';

  // name
  const tdName = document.createElement('td');
  const inputName = document.createElement('input');
  inputName.type = 'text';
  inputName.value = node.name || '';
  inputName.dataset.field = 'name';
  const errName = document.createElement('span');
  errName.className = 'field-error';
  tdName.appendChild(inputName);
  tdName.appendChild(errName);
  tr.appendChild(tdName);

  // parsed name (read-only display, updates on name input change)
  const tdParsed = document.createElement('td');
  tdParsed.className = 'parsed-name-cell';
  tdParsed.textContent = node.name ? formatParsedName(node.name, schema) : '';
  inputName.addEventListener('input', () => {
    tdParsed.textContent = inputName.value ? formatParsedName(inputName.value, schema) : '';
  });
  tr.appendChild(tdParsed);

  // type
  const tdType = document.createElement('td');
  const selectType = document.createElement('select');
  selectType.dataset.field = 'type';
  NODE_TYPES.forEach((t) => {
    const opt = document.createElement('option');
    opt.value = t;
    opt.textContent = t;
    if (t === node.type) opt.selected = true;
    selectType.appendChild(opt);
  });
  const errType = document.createElement('span');
  errType.className = 'field-error';
  tdType.appendChild(selectType);
  tdType.appendChild(errType);
  tr.appendChild(tdType);

  // model_id
  const tdModel = document.createElement('td');
  const selectModel = document.createElement('select');
  selectModel.dataset.field = 'model_id';
  // Empty option (no model)
  const optNone = document.createElement('option');
  optNone.value = '';
  optNone.textContent = '—';
  if (node.model_id == null) optNone.selected = true;
  selectModel.appendChild(optNone);
  models.forEach((m) => {
    const opt = document.createElement('option');
    opt.value = m.id;
    opt.textContent = m.name;
    if (m.id === node.model_id) opt.selected = true;
    selectModel.appendChild(opt);
  });
  const errModel = document.createElement('span');
  errModel.className = 'field-error';
  tdModel.appendChild(selectModel);
  tdModel.appendChild(errModel);
  tr.appendChild(tdModel);

  // ip
  const tdIp = document.createElement('td');
  const inputIp = document.createElement('input');
  inputIp.type = 'text';
  inputIp.value = node.ip || '';
  inputIp.dataset.field = 'ip';
  const errIp = document.createElement('span');
  errIp.className = 'field-error';
  tdIp.appendChild(inputIp);
  tdIp.appendChild(errIp);
  tr.appendChild(tdIp);

  // mac
  const tdMac = document.createElement('td');
  const inputMac = document.createElement('input');
  inputMac.type = 'text';
  inputMac.value = node.mac || '';
  inputMac.dataset.field = 'mac';
  const errMac = document.createElement('span');
  errMac.className = 'field-error';
  tdMac.appendChild(inputMac);
  tdMac.appendChild(errMac);
  tr.appendChild(tdMac);

  // Actions
  const tdActions = document.createElement('td');
  const btnSave = document.createElement('button');
  btnSave.textContent = 'Сохр.';
  btnSave.addEventListener('click', () => onSave(tr));

  const btnCancel = document.createElement('button');
  btnCancel.textContent = 'Отмена';
  btnCancel.addEventListener('click', () => onCancel(tr, node));

  tdActions.appendChild(btnSave);
  tdActions.appendChild(btnCancel);
  tr.appendChild(tdActions);

  return tr;
}

/**
 * Создаёт пустую редактируемую строку для добавления новой ноды.
 *
 * @param {Array} models — массив объектов моделей
 * @param {string[]} schema — схема сегментов
 * @param {Function} onSave — callback при нажатии Save
 * @returns {HTMLTableRowElement}
 */
export function createNewNodeRow(models, schema, onSave) {
  const tr = document.createElement('tr');
  tr.dataset.newRow = 'true';

  // name
  const tdName = document.createElement('td');
  const inputName = document.createElement('input');
  inputName.type = 'text';
  inputName.value = '';
  inputName.placeholder = 'Имя ноды';
  inputName.dataset.field = 'name';
  const errName = document.createElement('span');
  errName.className = 'field-error';
  tdName.appendChild(inputName);
  tdName.appendChild(errName);
  tr.appendChild(tdName);

  // parsed name (read-only display, updates on name input change)
  const tdParsed = document.createElement('td');
  tdParsed.className = 'parsed-name-cell';
  tdParsed.textContent = '';
  inputName.addEventListener('input', () => {
    tdParsed.textContent = inputName.value ? formatParsedName(inputName.value, schema) : '';
  });
  tr.appendChild(tdParsed);

  // type
  const tdType = document.createElement('td');
  const selectType = document.createElement('select');
  selectType.dataset.field = 'type';
  NODE_TYPES.forEach((t) => {
    const opt = document.createElement('option');
    opt.value = t;
    opt.textContent = t;
    selectType.appendChild(opt);
  });
  const errType = document.createElement('span');
  errType.className = 'field-error';
  tdType.appendChild(selectType);
  tdType.appendChild(errType);
  tr.appendChild(tdType);

  // model_id
  const tdModel = document.createElement('td');
  const selectModel = document.createElement('select');
  selectModel.dataset.field = 'model_id';
  const optNone = document.createElement('option');
  optNone.value = '';
  optNone.textContent = '—';
  optNone.selected = true;
  selectModel.appendChild(optNone);
  models.forEach((m) => {
    const opt = document.createElement('option');
    opt.value = m.id;
    opt.textContent = m.name;
    selectModel.appendChild(opt);
  });
  const errModel = document.createElement('span');
  errModel.className = 'field-error';
  tdModel.appendChild(selectModel);
  tdModel.appendChild(errModel);
  tr.appendChild(tdModel);

  // ip
  const tdIp = document.createElement('td');
  const inputIp = document.createElement('input');
  inputIp.type = 'text';
  inputIp.value = '';
  inputIp.placeholder = '192.168.1.1';
  inputIp.dataset.field = 'ip';
  const errIp = document.createElement('span');
  errIp.className = 'field-error';
  tdIp.appendChild(inputIp);
  tdIp.appendChild(errIp);
  tr.appendChild(tdIp);

  // mac
  const tdMac = document.createElement('td');
  const inputMac = document.createElement('input');
  inputMac.type = 'text';
  inputMac.value = '';
  inputMac.placeholder = 'AA:BB:CC:DD:EE:FF';
  inputMac.dataset.field = 'mac';
  const errMac = document.createElement('span');
  errMac.className = 'field-error';
  tdMac.appendChild(inputMac);
  tdMac.appendChild(errMac);
  tr.appendChild(tdMac);

  // Actions
  const tdActions = document.createElement('td');
  const btnSave = document.createElement('button');
  btnSave.textContent = 'Сохр.';
  btnSave.addEventListener('click', () => onSave(tr));
  tdActions.appendChild(btnSave);
  tr.appendChild(tdActions);

  return tr;
}

/**
 * Считывает данные из строки таблицы (редактируемой или новой).
 *
 * @param {HTMLTableRowElement} tr
 * @returns {Object} — объект с полями name, type, model_id, ip, mac
 */
function collectNodeRowData(tr) {
  const data = {};
  tr.querySelectorAll('[data-field]').forEach((el) => {
    const field = el.dataset.field;
    const value = el.value.trim();
    if (field === 'model_id') {
      data[field] = value === '' ? null : Number(value);
    } else {
      data[field] = value === '' ? null : value;
    }
  });
  return data;
}

/**
 * Очищает все ошибки в строке таблицы.
 *
 * @param {HTMLTableRowElement} tr
 */
function clearNodeRowErrors(tr) {
  tr.querySelectorAll('.field-error').forEach((el) => {
    el.textContent = '';
  });
}

function showNodeFieldError(tr, fieldName, message) {
  const target = tr.querySelector(`[data-field="${fieldName}"]`);
  if (target) {
    const errSpan = target.parentElement.querySelector('.field-error');
    if (errSpan) errSpan.textContent = message;
  }
}

function showNodeApiError(tr, errorMessage) {
  const match1 = errorMessage.match(/Field '(\w+)'/i);
  const match2 = errorMessage.match(/for field '(\w+)'/i);
  const field = (match1 && match1[1]) || (match2 && match2[1]) || 'name';
  const target = tr.querySelector(`[data-field="${field}"]`);
  if (target) {
    const errSpan = target.parentElement.querySelector('.field-error');
    if (errSpan) { errSpan.textContent = errorMessage; return; }
  }
  showNodeFieldError(tr, 'name', errorMessage);
}

/**
 * Рендерит таблицу нод в указанный tbody.
 * Добавляет строки для каждой ноды и пустую редактируемую строку в конце.
 *
 * @param {Array} nodes — массив объектов нод
 * @param {HTMLTableSectionElement} tbody — элемент tbody таблицы
 * @param {Array} models — массив объектов моделей (для выпадающего списка)
 * @param {string[]} schema — схема сегментов (из getSchema())
 * @param {Function} onRefresh — callback для обновления таблицы (перезагрузка данных)
 */
export function renderNodes(nodes, tbody, models, schema, onRefresh) {
  tbody.innerHTML = '';

  nodes.forEach((node) => {
    const onEdit = (tr, n) => {
      const editRow = createEditNodeRow(
        n,
        models,
        schema,
        async (editTr) => {
          clearNodeRowErrors(editTr);
          const data = collectNodeRowData(editTr);
          try {
            await updateNode(n.id, data);
            if (onRefresh) onRefresh();
          } catch (err) {
             showNodeApiError(editTr, err.apiError || err.message);
          }
        },
        (editTr, original) => {
          // Cancel: replace edit row with original view row
          const viewRow = createNodeRow(original, models, schema, onEdit, onDeleteHandler);
          editTr.replaceWith(viewRow);
        },
      );
      tr.replaceWith(editRow);
    };

    const onDeleteHandler = async (id, tr) => {
      try {
        await deleteNode(id);
        tr.remove();
      } catch (err) {
        alert(err.message);
      }
    };

    const row = createNodeRow(node, models, schema, onEdit, onDeleteHandler);
    tbody.appendChild(row);
  });

  // Пустая редактируемая строка в конце таблицы
  const newRow = createNewNodeRow(models, schema, async (tr) => {
    clearNodeRowErrors(tr);
    const data = collectNodeRowData(tr);
    try {
      await createNode(data);
      if (onRefresh) onRefresh();
    } catch (err) {
      showNodeApiError(tr, err.apiError || err.message);
    }
  });
  tbody.appendChild(newRow);
}

/**
 * Инициализирует страницу реестра нод.
 * Загружает данные и рендерит таблицу.
 *
 * @param {HTMLTableSectionElement} tbody
 * @param {HTMLElement} errorContainer — элемент для отображения глобальных ошибок
 * @param {string[]} schema — схема сегментов (из getSchema())
 */
export async function initNodesPage(tbody, errorContainer, schema) {
  const refresh = async () => {
    try {
      const [nodes, models] = await Promise.all([loadNodes(), loadModels()]);
      renderNodes(nodes, tbody, models, schema, refresh);
    } catch (err) {
      if (errorContainer) {
        errorContainer.textContent = `Ошибка загрузки: ${err.message}`;
      }
    }
  };

  await refresh();
}
