/**
 * Name_Parser — клиентский модуль разбора имён нод по разделителю «-».
 *
 * Схема по умолчанию: ['building', 'floor', 'cabinet', 'device']
 * Пользовательская схема хранится в localStorage под ключом `parseSchema`.
 */

/** Схема по умолчанию */
export const DEFAULT_SCHEMA = ['building', 'floor', 'cabinet', 'device'];

/**
 * Разбирает строку имени ноды по разделителю «-» согласно переданной схеме.
 *
 * @param {string} name   — имя ноды (например, «B1-2-301-PC01»)
 * @param {string[]} [schema=DEFAULT_SCHEMA] — массив меток сегментов
 * @returns {Object} — объект {label: value} только для присутствующих сегментов;
 *                     при пустой строке возвращает {}
 */
export function parseName(name, schema = DEFAULT_SCHEMA) {
  if (typeof name !== 'string' || name === '') {
    return {};
  }

  const segments = name.split('-');
  const result = {};

  for (let i = 0; i < segments.length; i++) {
    const label = schema[i];
    if (label !== undefined) {
      result[label] = segments[i];
    }
  }

  if (segments.length > schema.length) {
    result._extra = segments.slice(schema.length);
  }

  return result;
}

/**
 * Восстанавливает строку имени из объекта, возвращённого parseName.
 * Значения соединяются через «-» в порядке их перечисления в объекте,
 * включая сегменты из массива _extra (для сохранения round-trip).
 *
 * @param {Object} parsed — результат parseName
 * @returns {string} — сегменты, соединённые через «-»
 */
export function reconstructName(parsed) {
  if (!parsed || typeof parsed !== 'object') {
    return '';
  }

  const { _extra, ...labeled } = parsed;
  const values = Object.values(labeled);
  const extra = Array.isArray(_extra) ? _extra : [];

  return [...values, ...extra].join('-');
}
