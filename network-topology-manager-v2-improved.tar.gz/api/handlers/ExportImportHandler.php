<?php

declare(strict_types=1);

require_once __DIR__ . '/BaseHandler.php';

/**
 * ExportImportHandler — экспорт и импорт данных БД в JSON-файлы.
 *
 * Экспорт: GET  /api/export  — сохраняет все таблицы в /srv/network-topology-export.json
 * Импорт: POST /api/import   — загружает данные из /srv/network-topology-export.json
 * Список: GET  /api/export/list — возвращает список файлов экспорта в /srv
 */
class ExportImportHandler extends BaseHandler
{
    private const EXPORT_DIR = '/srv';

    /**
     * GET /api/export — экспортирует все данные в JSON-файл.
     */
    public function export(): void
    {
        $models = $this->db->query('SELECT * FROM model ORDER BY id')->fetchAll();
        $nodes = $this->db->query('SELECT * FROM node ORDER BY id')->fetchAll();
        $connections = $this->db->query('SELECT * FROM connection ORDER BY id')->fetchAll();

        $data = [
            'exported_at' => date('Y-m-d H:i:s'),
            'models' => $models,
            'nodes' => $nodes,
            'connections' => $connections,
        ];

        $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

        $dir = self::EXPORT_DIR;
        if (!is_dir($dir)) {
            if (!@mkdir($dir, 0777, true)) {
                jsonError("Cannot create export directory: {$dir}", 500);
            }
        }

        $filename = 'network-topology-export-' . date('Ymd-His') . '.json';
        $filepath = $dir . '/' . $filename;

        if (file_put_contents($filepath, $json) === false) {
            jsonError("Failed to write export file: {$filepath}", 500);
        }

        jsonResponse([
            'message' => 'Export successful',
            'filename' => $filename,
            'path' => $filepath,
            'models_count' => count($models),
            'nodes_count' => count($nodes),
            'connections_count' => count($connections),
        ]);
    }

    /**
     * POST /api/import — импортирует данные из JSON-файла.
     *
     * Body: { "filename": "network-topology-export-20250101-120000.json" }
     */
    public function import(): void
    {
        $body = $this->parseBody();
        $filename = $body['filename'] ?? '';

        if ($filename === '') {
            jsonError("Field 'filename' is required", 400);
        }

        // Prevent directory traversal
        $basename = basename($filename);
        $filepath = self::EXPORT_DIR . '/' . $basename;

        if (!is_file($filepath)) {
            jsonError("File not found: {$basename}", 404);
        }

        $raw = file_get_contents($filepath);
        if ($raw === false) {
            jsonError("Failed to read file: {$basename}", 500);
        }

        $data = json_decode($raw, true);
        if (!is_array($data)) {
            jsonError("Invalid JSON in file: {$basename}", 400);
        }

        $models = $data['models'] ?? [];
        $nodes = $data['nodes'] ?? [];
        $connections = $data['connections'] ?? [];

        $this->db->exec('PRAGMA foreign_keys = OFF;');
        $this->db->beginTransaction();

        try {
            // Clear existing data
            $this->db->exec('DELETE FROM connection');
            $this->db->exec('DELETE FROM node');
            $this->db->exec('DELETE FROM model');

            // Reset autoincrement counters
            $this->db->exec("DELETE FROM sqlite_sequence WHERE name IN ('model','node','connection')");

            // Import models
            $stmtModel = $this->db->prepare(
                'INSERT INTO model (id, name, type, rank, width, height) VALUES (:id, :name, :type, :rank, :width, :height)'
            );
            foreach ($models as $m) {
                $stmtModel->execute([
                    ':id' => $m['id'],
                    ':name' => $m['name'],
                    ':type' => $m['type'],
                    ':rank' => $m['rank'],
                    ':width' => $m['width'],
                    ':height' => $m['height'],
                ]);
            }

            // Import nodes
            $stmtNode = $this->db->prepare(
                'INSERT INTO node (id, name, type, model_id, ip, mac) VALUES (:id, :name, :type, :model_id, :ip, :mac)'
            );
            foreach ($nodes as $n) {
                $stmtNode->execute([
                    ':id' => $n['id'],
                    ':name' => $n['name'],
                    ':type' => $n['type'],
                    ':model_id' => $n['model_id'],
                    ':ip' => $n['ip'] ?? null,
                    ':mac' => $n['mac'] ?? null,
                ]);
            }

            // Import connections
            $stmtConn = $this->db->prepare(
                'INSERT INTO connection (id, src_node_id, dst_node_id, src_port_id, dst_port_id, type_line, colour_line) VALUES (:id, :src_node_id, :dst_node_id, :src_port_id, :dst_port_id, :type_line, :colour_line)'
            );
            foreach ($connections as $c) {
                $stmtConn->execute([
                    ':id' => $c['id'],
                    ':src_node_id' => $c['src_node_id'],
                    ':dst_node_id' => $c['dst_node_id'],
                    ':src_port_id' => $c['src_port_id'] ?? null,
                    ':dst_port_id' => $c['dst_port_id'] ?? null,
                    ':type_line' => $c['type_line'] ?? 'normal',
                    ':colour_line' => $c['colour_line'] ?? '#000000',
                ]);
            }

            $this->db->commit();
            $this->db->exec('PRAGMA foreign_keys = ON;');

            jsonResponse([
                'message' => 'Import successful',
                'models_count' => count($models),
                'nodes_count' => count($nodes),
                'connections_count' => count($connections),
            ]);
        } catch (\Throwable $e) {
            $this->db->rollBack();
            $this->db->exec('PRAGMA foreign_keys = ON;');
            jsonError('Import failed: ' . $e->getMessage(), 500);
        }
    }

    /**
     * GET /api/export/list — список файлов экспорта в /srv.
     */
    public function listFiles(): void
    {
        $dir = self::EXPORT_DIR;
        $files = [];

        if (is_dir($dir)) {
            $entries = scandir($dir);
            foreach ($entries as $entry) {
                if ($entry === '.' || $entry === '..') continue;
                if (!str_starts_with($entry, 'network-topology-export')) continue;
                if (!str_ends_with($entry, '.json')) continue;
                $fullPath = $dir . '/' . $entry;
                $files[] = [
                    'filename' => $entry,
                    'size' => filesize($fullPath),
                    'modified' => date('Y-m-d H:i:s', filemtime($fullPath)),
                ];
            }
        }

        usort($files, fn($a, $b) => strcmp($b['filename'], $a['filename']));

        jsonResponse($files);
    }
}
